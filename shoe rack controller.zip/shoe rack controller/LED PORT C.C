#include<pic.h>
#include<htc.h>
viod main()
{
	int i;
	TRISC=0X00;
	while(1)
	{
	PORTC=0XFF;
//	for(i=0;i<2000;i++)
//	{
//		}
	PORTC=0X00;
	}
	}